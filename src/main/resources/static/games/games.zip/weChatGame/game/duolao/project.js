{
    "project_type": "javascript",

    "debugMode" : 0,
    "showFPS" : false,
    "frameRate" : 60,
    "id" : "gameCanvas",
    "renderMode" : 1,
    "modules" : [
        "cocos2d"
    ],

    "jsList" : [
        "game.min.js",
        
        "src/app.js"
    ]
}
