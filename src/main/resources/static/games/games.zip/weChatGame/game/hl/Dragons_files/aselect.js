function pickAdURL(){
	var slotURL="";
	slotURL='http://img.tongji.linezing.com/3455448/tongji.gif';
	g.banad.innerHTML='<iframe src="'+slotURL+'" width="319" height="50" frameborder="0" scrolling="no">i</iframe>';
};