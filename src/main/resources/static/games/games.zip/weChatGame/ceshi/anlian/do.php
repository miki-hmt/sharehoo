<?php

echo mt_rand(0,11);