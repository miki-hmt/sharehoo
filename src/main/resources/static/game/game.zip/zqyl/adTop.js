document.writeln('<script type="text/javascript">');
document.writeln('/*wx.9ku.com 20:3，创建于2014-7-6*/');
document.writeln('var cpro_id = "u1612160";');
document.writeln('</script>');
document.writeln('<script src="cm.js"/*tpa=http://cpro.baidustatic.com/cpro/ui/cm.js*/ type="text/javascript"></script>');